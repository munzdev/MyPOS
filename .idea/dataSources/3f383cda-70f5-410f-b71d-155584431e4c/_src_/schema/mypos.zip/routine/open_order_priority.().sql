CREATE PROCEDURE open_order_priority()
  BEGIN
SET @rank:=0, @last_menu_groupid:=0, @last_orderid:=0;
DROP TABLE IF EXISTS tmp_open_order_priority;
CREATE TEMPORARY TABLE tmp_open_order_priority AS (
SELECT t.order_detailid, t.menu_groupid, t.orderid,
		IF(@last_menu_groupid != t.menu_groupid, @rank:=0, null) AS tmp1,
        IF(@last_orderid != t.orderid, @rank:=@rank+1, null) AS tmp2,
		IF(@last_menu_groupid != t.menu_groupid, @last_menu_groupid := t.menu_groupid, null) AS tmp3,
        IF(@last_orderid != t.orderid, @last_orderid := t.orderid, null) AS tmp4,
        @rank AS rank
FROM (SELECT order_detailid, menu_groupid, priority, orderid
FROM (SELECT od.order_detailid, m.menu_groupid, o.priority, o.orderid
			 FROM `order` o
			 INNER JOIN order_details od ON od.orderid = o.orderid AND od.finished IS NULL
			 INNER JOIN menu m ON m.menuid = od.menuid
			 WHERE o.finished IS NULL) f
	  ORDER BY  menu_groupid ASC, priority ASC
      LIMIT 18446744073709551615) t);
END;
